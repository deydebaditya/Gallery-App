package com.deba.gallery;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.view.GestureDetectorCompat;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;

/**
 * Created by deba on 2/6/16.
 */
public class viewImage extends MainActivity {

    int position;
    ImageView showImage;
    String filepath[];
    String filename[];
    private float init_x=0,fin_x=0;
//    private GestureDetectorCompat gestureDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.img_layout);
        showImage = (ImageView) findViewById(R.id.showImage);
        Intent i = getIntent();
        position = i.getExtras().getInt("position");

        filepath = i.getStringArrayExtra("filepath");

        filename = i.getStringArrayExtra("filename");

        Bitmap bmp = BitmapFactory.decodeFile(filepath[position]);
        showImage.setImageBitmap(bmp);

        //TO DETECT SWIPE GESTURES//
        showImage.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                int action=event.getActionMasked();
                switch(action)
                {
                    case MotionEvent.ACTION_DOWN:
                        init_x=event.getX();
                        Log.e("Action","finger down");
                        break;
                    case MotionEvent.ACTION_UP:
                        fin_x=event.getX();
                        Log.e("Action","finger up");
                        if(fin_x>init_x)
                        {
                            Log.e("Action","Swipe left");
                            if(!(position==0))
                            {
                                position-=1;
                                Bitmap bmp=BitmapFactory.decodeFile(filepath[position]);
                                showImage.setImageBitmap(bmp);
                            }
                        }
                        else
                        {
                            if(fin_x<init_x)
                            {
                                Log.e("Action","Swipe right");
                                position+=1;
                                Bitmap bmp=BitmapFactory.decodeFile(filepath[position]);
                                showImage.setImageBitmap(bmp);
                            }
                        }
                        break;
                }
                return true;
            }
        });
    }
}