package com.deba.gallery;
//TODO: Smooth Scrolling & Popup on new actvity, see to it that all directories are reached.

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.LruCache;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    GridView gv;
    ArrayList<File> images;
    String path[],name[];
    LruCache<File,Bitmap> myCache=new LruCache<>((int)Runtime.getRuntime().maxMemory()/1024);//TODO NEW USE IT
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gv=(GridView)findViewById(R.id.gridView);
        images=imageReader(Environment.getExternalStorageDirectory());
        final CacheThread cacheThread=new CacheThread();
        cacheThread.start();
        gv.setAdapter(new GridAdapter());
        path=new String[images.size()];
        name=new String[images.size()];
        for(int i=0;i<images.size();i++)
        {
            path[i]=images.get(i).getAbsolutePath();
            name[i]=images.get(i).getName();
//            myCache.put(images.get(i), ThumbnailUtils.extractThumbnail(BitmapFactory.decodeFile(images.get(i).toString()), 100, 100));
        }
        gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent showImage=new Intent(MainActivity.this,viewImage.class);

                showImage.putExtra("filepath",path);
                showImage.putExtra("filename",name);
                showImage.putExtra("position",position);
                startActivity(showImage);
            }
        });
    }
    class CacheThread extends Thread{
        public void run()
        {
            for(int i=0;i<images.size();i++)
            {
                myCache.put(images.get(i), ThumbnailUtils.extractThumbnail(BitmapFactory.decodeFile(images.get(i).toString()), 100, 100));
                yield();
            }
        }
    }
    class GridAdapter extends BaseAdapter
    {
        private Activity activity;
        @Override
        public int getCount() {
            return images.size();
        }

        @Override
        public Object getItem(int position) {
            return images.get(position);
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }//if we use database

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            convertView= getLayoutInflater().inflate(R.layout.singleview,parent,false);
            ImageView newimg= (ImageView) convertView.findViewById(R.id.imageView);
//            newimg.setImageBitmap(ThumbnailUtils.extractThumbnail(BitmapFactory.decodeFile(getItem(position).toString()), 100, 100));
            newimg.setImageBitmap(myCache.get((File) getItem(position)));
            return convertView;
        }//this method will set each and every image to the grid view
    }
    ArrayList<File> a = new ArrayList<>();

    ArrayList<File> imageReader(File root) {

        addtolist(root);
//        File files[] = root.listFiles();
//        Log.e("Images adding","Image adding started!");
//        for (int i = 0; i < files.length; i++) {
//            if (files[i].isDirectory()) {
//                Log.e("Directory Found","Directory!");
//                File sub_files[]=files[i].listFiles();
//                for(int j=0;j<sub_files.length;j++)
//                {
//                    if(sub_files[j].isDirectory())
//                    {
//                        continue;//Problematic code. TODO: CHECK!
//                    }
//                    else
//                    {
//                        if(sub_files[j].getName().endsWith(".jpg"))
//                        {
//                            a.add(sub_files[j]);
//                        }
//                    }
//                }
//            } else {
//                if (files[i].getName().endsWith(".jpg")) {
//                    a.add(files[i]);
//                    Log.e("Image added",files[i].toString());
//                }
//            }
//        }
        return a;
    }
    void addtolist(File root){
        File files[]=root.listFiles();
        for(int i=0;i<files.length;i++)
        {
            if(files[i].isDirectory()){
                addtolist(files[i]);
            }
            else
            {
                if(files[i].getName().endsWith(".jpg"))
                {
                    a.add(files[i]);
                }
            }
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_settings:
                // User chose the "Settings" item, show the app settings UI...
                return true;

            case R.id.action_favorite:
                // User chose the "Favorite" action, mark the current item
                // as a favorite...
                return true;

            default:
                // If we got here, the user's action was not recognized.
                // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);

        }
    }
}

